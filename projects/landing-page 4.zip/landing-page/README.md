# Landing Page Project

**By Roeya ElHawary for the EGYPT FWD program**

## Usage

There is no special usage for this project. This is just to display the skills learned from the first two chapters in the UDACITY frontend nanodegree program.

## Instructions

Open the index.html file to view the results of my work!.
